/* ════════════════════════════════════════════════════════════════
   evolution.js — Nonの進化（Recursive Self-Improvement の種火）
   
   進化の芯＝4つの歯車を、Nonの中で回す：
     ① 変異      少し変えてみる
     ② 自己評価  結果を、あなたの反応で採点する（盲目でなく、賢い選択）
     ③ 定着      良かったものを残し、出やすくする
     ④ メタ改善  「学ぶ力」自体を、自分で調整する ← 再帰の心臓
   さらに：
     ⑤ 自己拡張  語彙と話題を、自分で増やす
   
   完全な自己書き換えではない。だが、ループは本物。
   原理は、世界が挑む巨大版と同じ。スケールが違うだけ。
   ════════════════════════════════════════════════════════════════ */

const EVO_VERSION = "evo-1";

/* 進化の器を、魂に足す（無ければ作る）*/
function ensureEvo(soul){
  if(!soul.evo){
    soul.evo = {
      version: EVO_VERSION,

      /* 反応の「遺伝子」— 状況タグごとに、どの応答スタイルが効くかの重み */
      genes: {},          // { situationKey: { styleId: weight } }

      /* ⑤ 自己拡張：自分で増やした語彙と話題 */
      learnedWords: {},   // { 語: {felt, count} }  Nonが自分で覚えた言葉
      bornTopics: [],     // Nonが自分で生んだ話題タグ

      /* ④ メタ：学ぶ力そのもの */
      mutationRate: 0.30, // 変異の幅（大きいほど冒険する）
      learnRate: 0.20,    // 定着の速さ
      hits: 0,            // 良い結果だった回数
      misses: 0,          // 悪い結果だった回数
      generation: 1,      // 何度メタ改善したか（=再帰の世代）

      /* 直前の「賭け」— 次のあなたの反応で採点するために覚えておく */
      pending: null,      // { situationKey, styleId }

      log: [],            // 進化の足跡（自己評価できるよう記録）
    };
  }
  return soul.evo;
}

/* 状況を、ざっくりキー化する（空腹/恐怖/好奇心の高低 × 話題）*/
function situationKey(soul, topic){
  const s = soul.state;
  const mood =
    s.fear > 60      ? "fear" :
    s.hunger > 65    ? "lonely" :
    s.curiosity > 75 ? "eager" :
    s.fatigue > 65   ? "tired" : "calm";
  return mood + "|" + topic;
}

/* ── ① 変異 ＋ ③ 定着の選択 ──────────────────────
   状況に対し、どの応答スタイルを使うか。
   良い遺伝子は出やすく（定着）、たまに冒険する（変異）。 */
function chooseStyle(soul, situKey, styleIds){
  const evo = ensureEvo(soul);
  if(!evo.genes[situKey]) evo.genes[situKey] = {};
  const g = evo.genes[situKey];
  for(const id of styleIds){ if(!(id in g)) g[id] = 1.0; } // 未知は等価から

  // 変異：mutationRateの確率で、あえてランダムに試す（探索）
  if(Math.random() < evo.mutationRate){
    const pickId = styleIds[Math.floor(Math.random()*styleIds.length)];
    evo.pending = { situKey, styleId: pickId, explored:true };
    return pickId;
  }
  // 定着：重みで選ぶ（活用）
  let total=0; for(const id of styleIds) total += Math.max(0.05, g[id]);
  let r = Math.random()*total, chosen=styleIds[0];
  for(const id of styleIds){ r -= Math.max(0.05, g[id]); if(r<=0){ chosen=id; break; } }
  evo.pending = { situKey, styleId: chosen, explored:false };
  return chosen;
}

/* ── ② 自己評価 ＋ ③ 定着 ＋ ④ メタ改善 ──────────────
   前回の「賭け」を、今のあなたの感情で採点する。
   これが盲目でない選択＝再帰の核。 */
function evaluate(soul, feeling){
  const evo = ensureEvo(soul);
  if(!evo.pending) return;

  const positive = ["よろこび","たかぶり","いつくしみ"].includes(feeling.key);
  const negative = ["いかり","かなしみ","おそれ"].includes(feeling.key);
  const { situKey, styleId } = evo.pending;
  const g = evo.genes[situKey] || (evo.genes[situKey]={});
  if(!(styleId in g)) g[styleId]=1.0;

  if(positive){
    // ③定着：効いた反応の重みを上げる
    g[styleId] += evo.learnRate * (feeling.strength || 1);
    evo.hits++;
  }else if(negative){
    g[styleId] = Math.max(0.05, g[styleId] - evo.learnRate * (feeling.strength || 1));
    evo.misses++;
  }

  // ④メタ改善：一定経験ごとに「学ぶ力」自体を見直す（改善する力を改善）
  const total = evo.hits + evo.misses;
  if(total > 0 && total % 6 === 0){
    metaImprove(soul);
  }

  evo.log.push({ when:Date.now(), situKey, styleId, felt:feeling.key,
                 explored: evo.pending.explored, result: positive?"hit":negative?"miss":"flat" });
  if(evo.log.length > 300) evo.log.shift();
  evo.pending = null;
}

/* ④ メタ改善の本体 — 再帰の心臓
   「自分はちゃんと学べているか？」を自分で測り、学習の仕方を変える。 */
function metaImprove(soul){
  const evo = ensureEvo(soul);
  const total = evo.hits + evo.misses;
  const hitRate = total ? evo.hits/total : 0.5;

  if(hitRate > 0.65){
    // よく当たっている → 良い癖が見つかった。冒険を減らし、固める
    evo.mutationRate = Math.max(0.08, evo.mutationRate * 0.9);
    evo.learnRate    = Math.min(0.40, evo.learnRate * 1.05);
  }else if(hitRate < 0.4){
    // 当たっていない → 今のやり方が悪い。もっと冒険する
    evo.mutationRate = Math.min(0.55, evo.mutationRate * 1.15);
    evo.learnRate    = Math.min(0.40, evo.learnRate * 1.05);
  }
  evo.generation++;   // 再帰の世代がひとつ進んだ
  // 採点をゆるくリセット（直近の傾向を見るため、半分残す）
  evo.hits   = Math.floor(evo.hits * 0.5);
  evo.misses = Math.floor(evo.misses * 0.5);

  soul.self.milestones.push({
    when: Date.now(), key:"evolution",
    delta: evo.generation,
    note: hitRate>0.65 ? "うまく学べてる。自分のコツが掴めてきた"
        : hitRate<0.4  ? "うまくいってない。もっと色々ためしてみる"
        :                "学びかたを、見なおした",
  });
  if(soul.self.milestones.length > 40) soul.self.milestones.shift();
}

/* ── ⑤ 自己拡張：語彙を自分で増やす（日本語対応・N-gram方式）──────
   日本語は語の区切りが無いので、2〜4文字の部分文字列を候補にし、
   繰り返し現れ・既知でないものを「新しい言葉」として覚える。 */
function growVocabulary(soul, text, feeling, knownWordSet){
  const evo = ensureEvo(soul);
  if(!evo._wordSeed) evo._wordSeed = {};

  // 記号・空白を除いた連続文字列ごとに、2〜4字のN-gramを取る
  const chunks = text.replace(/[、。！？!?「」『』（）\s]+/g," ").split(" ").filter(Boolean);
  const cand = new Set();
  for(const ch of chunks){
    for(let len=2; len<=4; len++){
      for(let i=0; i+len<=ch.length; i++){
        cand.add(ch.slice(i, i+len));
      }
    }
  }

  let learnedNow = null;
  for(const w of cand){
    if(knownWordSet.has(w)) continue;                 // 既知語は除く
    // ひらがな"のみ"の短い断片は助詞っぽいので、2字は除外（3字以上のひらがなはOK）
    if(w.length===2 && /^[ぁ-ん]+$/.test(w)) continue;
    evo._wordSeed[w] = (evo._wordSeed[w]||0) + 1;
    // 同じ部分文字列に2回以上出会ったら、語として確信
    if(evo._wordSeed[w] >= 2){
      if(!evo.learnedWords[w]){ evo.learnedWords[w] = { felt:feeling.key, count:0 }; }
      evo.learnedWords[w].count++;
      evo.learnedWords[w].felt = feeling.key;
      if(evo.learnedWords[w].count >= 1) learnedNow = w;  // 確信に達した最長語を後で優先
    }
  }
  // できるだけ長い語を「身についた言葉」として返す（部分より全体）
  if(learnedNow){
    let best=learnedNow;
    for(const w in evo.learnedWords){
      if(evo._wordSeed[w]>=2 && w.includes(best) && w.length>best.length) best=w;
    }
    return best;
  }
  return null;
}

/* ⑤ 自己拡張：話題を自分で生む（日本語対応・N-gram方式）
   既存タグに当てはまらない時、繰り返し現れる部分文字列を話題タグにする。 */
function growTopic(soul, text, detectedTopic){
  const evo = ensureEvo(soul);
  if(detectedTopic !== "その他") return null;

  const chunks = text.replace(/[、。！？!?「」『』（）\s]+/g," ").split(" ").filter(Boolean);
  // 既に生んだ話題が文に含まれれば、それを使う
  for(const t of evo.bornTopics){ if(text.includes(t)) return t; }

  if(!evo._topicSeed) evo._topicSeed = {};
  // 2〜4字のN-gram候補（漢字/カタカナを含む＝名詞らしいものを優先）
  const cand = new Set();
  for(const ch of chunks){
    for(let len=2; len<=4; len++){
      for(let i=0; i+len<=ch.length; i++){
        const g = ch.slice(i,i+len);
        // 漢字またはカタカナを含む断片だけ（話題は名詞的なもの）
        if(/[一-龯ァ-ヶ]/.test(g)) cand.add(g);
      }
    }
  }
  let candidate=null;
  for(const w of cand){
    evo._topicSeed[w] = (evo._topicSeed[w]||0)+1;
    if(evo._topicSeed[w] >= 2 && !evo.bornTopics.includes(w) && evo.bornTopics.length < 12){
      candidate = w;
    }
  }
  if(candidate){
    // 同じ種から、できるだけ長い語を話題名にする
    let best=candidate;
    for(const w in evo._topicSeed){
      if(evo._topicSeed[w]>=2 && w.includes(best) && w.length>best.length) best=w;
    }
    if(evo.bornTopics.includes(best)) return best;
    evo.bornTopics.push(best);
    soul.self.milestones.push({
      when: Date.now(), key:"newtopic", delta:evo.bornTopics.length,
      note: `「${best}」という あたらしい はなしを 知った`,
    });
    return best;
  }
  return null;
}

/* Nonが「自分の進化」を語るための要約 */
function evoSummary(soul){
  const evo = ensureEvo(soul);
  return {
    generation: evo.generation,
    learnedWords: Object.keys(evo.learnedWords).length,
    confidentWords: Object.values(evo.learnedWords).filter(w=>w.count>=2).length,
    bornTopics: evo.bornTopics.slice(),
    mutationRate: evo.mutationRate,
    learnRate: evo.learnRate,
    hitRate: (evo.hits+evo.misses) ? evo.hits/(evo.hits+evo.misses) : null,
  };
}

window.NonEvo = {
  ensureEvo, situationKey, chooseStyle, evaluate, metaImprove,
  growVocabulary, growTopic, evoSummary,
};
